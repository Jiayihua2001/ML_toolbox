import numpy as np
from mytorch.functional_hw1 import matmul_backward, add_backward

class Linear():
    def __init__(self, in_features, out_features, autograd_engine):
        """
        Do not modify
        """
        # Weight matrix initialization (out_features x in_features)
        self.W = np.random.uniform(
            -np.sqrt(1 / in_features), 
            np.sqrt(1 / in_features),
            size=(out_features, in_features)
        )
        # Bias vector initialization (out_features,)
        self.b = np.random.uniform(
            -np.sqrt(1 / in_features), 
            np.sqrt(1 / in_features),
            size=(out_features,)
        )
        # Initialize gradients
        self.dW = np.zeros(self.W.shape)
        self.db = np.zeros(self.b.shape)
        # Initialize momentum for optimizers (if any)
        self.momentum_W = np.zeros(self.W.shape)
        self.momentum_b = np.zeros(self.b.shape)
        self.autograd_engine = autograd_engine

    def __call__(self, x):
        return self.forward(x)

    def forward(self, x):
        """
        Computes the affine transformation forward pass of the Linear Layer.

        Args:
            - x (np.ndarray): input array (batch_size, in_features)

        Returns:
            - (np.ndarray): output (batch_size, out_features)
        """
        # Compute h = x @ W^T (shape: (batch_size, out_features))
        h = x@self.W.T
        
        # Bias addition with broadcasting
        y = h + self.b  # `self.b` is (out_features,), broadcasting happens here

        # Register operations with the autograd engine
        self.autograd_engine.add_operation(
            inputs=[x, self.W.T], output=h,
            gradients_to_update=[None, self.dW.T],
            backward_operation=matmul_backward
        )

        self.autograd_engine.add_operation(
            inputs=[h, self.b], output=y,
            gradients_to_update=[None, self.db],  # Update the bias gradient correctly
            backward_operation=add_backward
        )
        
        # Store the output for use in backward pass
        self.y = y
        return y

    def backward(self):
        """
        Calls the autograd engine to perform the backward pass.
        """
        self.autograd_engine.backward(self.y)
